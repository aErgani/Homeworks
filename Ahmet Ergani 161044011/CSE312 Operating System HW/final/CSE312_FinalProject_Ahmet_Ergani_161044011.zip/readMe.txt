SC and WSClock are not supported.
Local allocation is not supported.
Part3 is not implemented.