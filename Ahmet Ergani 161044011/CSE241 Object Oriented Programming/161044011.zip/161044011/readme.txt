				__/**Connect Four Game**\__
Developer : Ahmet Ergani
Purpose : Homework for Object Oriented Programming Class
Type : JAVA Game
***************************************************************
				How To Play
As you start the game you will confront 2 input Dialogues
  ->First one will ask you the size of the GAME
		*You need to enter an integer from 4 to 18
  ->Second one will ask you the game type
		*You need to select YES if you want to play vs AI
		*You need to select NO if you want to play with a
		 partner
After that your board will be initialized. You need to 
click on the buttons(named with column names) at the top 
to add your characteristic cell to the board's columns. 
  ->Each move of player1 is a red Cell 
  ->Each move of player2 or AI is a blue Cell
The purpose of this game is to place your Cells in a way that
4 of them will be neighbors with each other in a horizontal
or vertical or diagonal direction.By the time you (or your 
opponent) achieve that, the Cells that creates a win situation
will transform into Snoop Dogg Cells.So yes.We can summarize
the purpose of this game as : GET THE SNOOP DOGG CELLS.