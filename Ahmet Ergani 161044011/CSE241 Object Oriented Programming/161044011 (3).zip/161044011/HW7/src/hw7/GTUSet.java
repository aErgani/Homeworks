/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package hw7;



import java.lang.reflect.Array;
import java.security.InvalidParameterException;
/**
 *<h1> GTUSet Class </h1>
 * This is the most important class of our homework.This is where I implement the
 * most of our methods by overriding them from our interface GTUSetInt
 * 
 * 
 * 
 * @author Ahmet Ergani
 * @param <T> is our unknown type
 */
public class GTUSet<T> implements GTUSetInt<T>
{
    /**
     * This is the java array that will hold the set
     */
    protected T[] data;
    /**
     * This field holds the type of our array
     */
    protected Class<T[]> dataType;
    /**
     * this is a constructor that takes an array type(class) as a parameter
     * @param cls 
     */
    GTUSet(Class<T[]> cls)
    {
        data = cls.cast(Array.newInstance(cls.getComponentType(), capacity));
        dataType = cls;
    }
    /**
     * This field holds the maximum size of the set
     */
    int capacity = 100;
    /**
     * This field holds the current count of the members in the set
     */
    int memberCount = 0;
    @Override 
    public boolean empty(){return memberCount == 0;}
    @Override 
    public int size(){return memberCount;}
    @Override 
    public int max_size(){return capacity;}
    @Override 
    public void insert(T val)
    {
        for (int i = 0;i < memberCount; i++) 
            if (data[i] == val) 
                throw new InvalidParameterException("This element is already in the set");
        if(memberCount == capacity)
        {
            T[] newData;
            newData = dataType.cast(Array.newInstance(dataType.getComponentType(), capacity * 2));
            System.arraycopy(data, 0, newData, 0, data.length);
            data = newData;
        }
        if(memberCount == 0)
            {
                data[0] = val;
                memberCount++;
                return;
            }
        data[memberCount] = val;
        memberCount++;
    }
    @Override
    public GTUSet<T> intersection(GTUSet<T> other)
    {
        GTUSet<T> newSet = new GTUSet<T>(dataType);
        for(int i = 0; i < this.memberCount; i++)
            for(int j = 0;j < other.memberCount;j++)
                if(this.data[i] == other.data[j])
                    newSet.insert(other.data[j]);
        return newSet;
    }
    @Override 
    public void erase(T val)
    {
        for(int i = 0;i < memberCount;i++)
            if(data[i] == val)
            {
                for(; i < memberCount;i++)
                    data[i] = data[i+1];
                memberCount--;
                return;
            }
        System.err.println("The value you wanted to erase could not be found at the set");
    }
    @Override 
    public void clear()
    {
        for (int i = 0;i < memberCount; i++)
            data[i] = null;
        memberCount = 0;
    }
    @Override 
    public int count(T val)
    {
        for(int i = 0;i < memberCount;i++)
            if(data[i] == val)
                return 1;
        return 0;
    }
    /**
     * This is the class that extends the GTUIterator(in GTUSetInt) and 
     * implements all of it's methods
     * @param <T> is the unknown type 
     */
    public class Iterator<T> extends GTUIterator<T>
    {
        int i;
        T cursor;
        @Override 
        public boolean hasNext()
        {
            for (i = 0;i < memberCount; i++)
                if(data[i] == cursor)
                    break;
            return i < memberCount - 1;
        }
        @Override 
        public boolean hasPrevious()
        {
            for(i = 0;i < memberCount; i++)
                if(data[i] == cursor)
                    break;
            return i > 0;
        }
        @Override 
        public T next()
        {
            for(i = 0;i < memberCount; i++)
                if(data[i] == cursor)
                {
                    cursor = (T) data[i + 1];
                    break;
                }
            return cursor;
        }
        @Override 
        public T previous()
        {
            for (i = 0;i < memberCount; i++)
                if(data[i] == cursor)
                {
                    cursor = (T) data[i - 1];
                    break;
                }
            return cursor;
        }
        @Override
        public T current()
        {
            return cursor;
        }
    }
    @Override 
    public Iterator find(T val)
    {
        Iterator<T> iter;
        iter = new Iterator<T>();
            for(int i = 0;i < memberCount; i++)
                if(data[i] == val)
                    iter.cursor = (T) data[i];
            return iter;
    }
    @Override public Iterator begin()
    {
        Iterator<T> iter;
        iter = new Iterator<T>();
        iter.cursor = (T) data[0];
        return iter;
    }
    @Override public Iterator end()
    {
        Iterator<T> iter;
        iter = new Iterator<T>();
        iter.cursor = (T) data[memberCount - 1];
        return iter;
    }
}
