/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package hw7;

import javafx.util.Pair;

/**
 * <h1> GTUMap Class </h1>
 * This class lets us create a set of pairs using javafx.util.Pair
 * @author Ahmet Ergani
 * @param <K> is the key part of the element
 * @param <V> is the value part of the element
 */
public class GTUMap<K, V> extends GTUSet< javafx.util.Pair <K, V> >
{
    /**
     * In this constructor we send our array type to the super class's (GTUSet)
     * constructor as a parameter
     * @param cls is array type (pair of unknown elements)
     */
    public GTUMap(Class<Pair<K, V>[]> cls) 
    {
        super(cls);
    }
    /**
     * This method checks the set and search for the given key value
     * @param k is the key value we search
     * @return value of the element that has the key element we search 
     */
    public V at(K k)
    {
        V val = null;
        for(int i = 0; i < memberCount; i++)
            if(data[i].getKey() == k)
                val = data[i].getValue();
        return val;
    }
    /**
     * The following methods are the same as the ones in GTUSet: 
     * hasNext() 
     * hasPrevious()
     * Remaining methods of this iterator class is very similar to the one in
     * GTUSet but instead of returning an element of the set, these methods
     * returns the value part of the elements since all of our set's elements
     * are pairs
     * @param <V> is the value part of the pair that the iterator shows
     */
    public class mapIterator<V> extends Iterator<V>
    {
        int j;
        javafx.util.Pair <K, V> mapCursor;
        @Override 
        public boolean hasNext()
        {
            for (j = 0;j < memberCount; j++)
                if(data[j] == mapCursor)
                    break;
            return j < memberCount - 1;
        }
        @Override 
        public boolean hasPrevious()
        {
            for(j = 0;j < memberCount; j++)
                if(data[j] == mapCursor)
                    break;
            return j > 0;
        }
        @Override 
        public V next()
        {
            for(j = 0;j < memberCount; j++)
                if(data[j] == mapCursor)
                {
                    mapCursor = (javafx.util.Pair <K, V>) data[j + 1];
                    break;
                }
            return mapCursor.getValue();
        }
        @Override 
        public V previous()
        {
            for (j = 0;j < memberCount; j++)
                if(data[j] == mapCursor)
                {
                    mapCursor = (javafx.util.Pair <K, V>) data[j - 1];
                    break;
                }
            return mapCursor.getValue();
        }
        @Override
        public V current()
        {
            return mapCursor.getValue();
        }
    }
    /**
     * 
     * @return the value part of the pair that the iterator shows  
     */
    @Override public mapIterator begin()
    {
        mapIterator<V> iter;
        iter = new mapIterator<V>();
        iter.mapCursor = (Pair<K, V>) (V) data[0];
        return iter;
    }
    /**
     * 
     * @return the value part of the pair that the iterator shows
     */
    @Override public mapIterator end()
    {
        mapIterator<V> iter;
        iter = new mapIterator<V>();
        iter.mapCursor = (Pair<K, V>) (V) data[memberCount - 1];
        return iter;
    }
}
