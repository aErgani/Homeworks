/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package hw7;
import java.security.InvalidParameterException;
import javafx.util.Pair;
/**
 *<h1>GTU CSE241 HOMEWORK !</h1>
 * HW7 is my driver class. It tests all the methods I implemented
 * 
 * 
 * @author Ahmet Ergani
 * can throw exceptions correctly
 */
public class HW7 
{

    /**
     * This is the main method where I create an object for each class I 
     * implemented and try every method of them
     * @param args unused
     * @throws InvalidParameterException always (to show that insert method can throw it successfully)
     */
    @SuppressWarnings("empty-statement")
    public static void main(String[] args) 
    {
        GTUSet<Integer> mySet = new GTUSet<Integer>(Integer[].class);
        GTUSetInt.GTUIterator<Integer> myCursor;
        GTUSetInt.GTUIterator<Integer> myCursor2;
        GTUSetInt.GTUIterator<Integer> myCursor3;
        System.out.println("************SET MANIPULATION PART************");
        System.out.print("set is ");
        if(mySet.empty())
            System.out.println("empty");
        else
            System.out.println("not empty");
        mySet.insert(25);
        mySet.insert(235);
        mySet.insert(15);
        mySet.insert(265);
        mySet.insert(13163);
        System.out.println("    inserted some elements");
        System.out.print("set is ");
        if(mySet.empty())
            System.out.println("empty");
        else
            System.out.println("not empty");
        System.out.println("    our set is:");
        myCursor = mySet.begin();
        for(int i = 0;i < mySet.memberCount; i++)
        {
            System.out.println(myCursor.current());
            myCursor.next();
        }
        mySet.clear();
        System.out.println("    clearing the set");
        System.out.println("    new set is:");
        mySet.insert(1);
        mySet.insert(3);
        mySet.insert(5);
        mySet.insert(4);
        mySet.insert(2);
        myCursor = mySet.begin();
        for(int i = 0;i < mySet.memberCount; i++)
        {
            System.out.println(myCursor.current());
            myCursor.next();
        }
        mySet.erase(4);
        System.out.println("    erased an element. last state of the set is:");
        myCursor = mySet.begin();
        for(int i = 0;i < mySet.memberCount; i++)
        {
            System.out.println(myCursor.current());
            myCursor.next();
        }
        System.out.println("    member count of the set is " + mySet.size());
        System.out.println("************ITERATOR PART************");
        myCursor = mySet.begin();
        myCursor.next();
        System.out.println(myCursor.previous() + " is the first member of our set");
        System.out.println("\tdo we have an element after that?");
        if(myCursor.hasNext())
            System.out.println("\t\tyes we have! and that element is " + myCursor.next());
        myCursor = mySet.end();
        myCursor.previous();
        System.out.println(myCursor.next() + " is the last member of our set");
        System.out.println("\tdo we have an element before that?");
        if(myCursor.hasPrevious())
            System.out.println("\t\tyes we have! and that element is " + myCursor.previous());
        System.out.println("************INTERSECTION PART************");
        System.out.println("    first set is:");
        myCursor = mySet.begin();
        for(int i = 0;i < mySet.memberCount; i++)
        {
            System.out.println(myCursor.current());
            myCursor.next();
        }
        GTUSet<Integer> mySet2 = new GTUSet<Integer>(Integer[].class);
        mySet2.insert(7);
        mySet2.insert(2);
        mySet2.insert(24626);
        mySet2.insert(3);
        mySet2.insert(75);
        mySet2.insert(4);
        System.out.println("    second set is:");
        myCursor2 = mySet2.begin();
        for(int i = 0;i < mySet2.memberCount; i++)
        {
            System.out.println(myCursor2.current());
            myCursor2.next();
        }
        GTUSet<Integer> interSet = mySet.intersection(mySet2);
        System.out.println("    intersection set is:");
        myCursor3 = interSet.begin();
        for(int i = 0;i < interSet.memberCount; i++)
        {
            System.out.println(myCursor3.current());
            myCursor3.next();
        }
        System.out.println("************MAP PART************");
        GTUMap<Integer,Character> myMap;
        myMap = new GTUMap(javafx.util.Pair[].class);
        myMap.insert(new Pair(4,'T'));
        myMap.insert(new Pair(2,'M'));
        myMap.insert(new Pair(1,'H'));
        myMap.insert(new Pair(0,'A'));
        myMap.insert(new Pair(3,'E'));
        System.out.println("added my name (AHMET) with indexes from 0 to 4");
        GTUSetInt.GTUIterator<Character> mapCursor = myMap.begin();
        System.out.println("printing the set with iterator");
        for(int i = 0;i < myMap.memberCount; i++)
        {
            System.out.println(mapCursor.current());
            if(mapCursor.hasNext())
                mapCursor.next();
        }
        System.out.println("printing the set using at() method from 0 to 4");
        for(int i = 0;i < myMap.memberCount; i++)
            System.out.println(myMap.at(i));
        System.out.println("************EXCEPTION************");
        System.out.println("We already have the element 5 in mySet. Lets try to insert 5 to it one more time");
        try {mySet.insert(5);}
        catch(InvalidParameterException exc)
        {
            System.out.println("EXCEPTION! " + exc.getMessage());
        }
    }
}
