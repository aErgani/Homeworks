/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package hw7;
import java.security.InvalidParameterException;

/**
 *<h1> GTUSet Interface</h1>
 * This is the desired interface
 * <p>
 * alongside the GTUIterator class, it also holds abstract methods that we 
 * are going to implement at GTUset.
 * 
 * @author Ahmet Ergani
 * @param <T> is our unknown type
 */
public interface GTUSetInt<T> 
{
    /**
     * <h2> GTUIterator </h2>
     * This is an abstract class.I extended it at both GTUSet and GTUMap classes 
     * since I need a different iterator for each one of them.
     *  
     * @param <T> is our unknown type 
     */
    public abstract class GTUIterator<T>
    {
        /**
         * Checks if there is an element after exists
         * @return true if iterator is not at the end / false if it is at the 
         * end 
         */
        public abstract boolean hasNext();
        /**
         * Checks if there is an element before exists
         * @return true if iterator is not at the beginning / false if it is at 
         * the beginning 
         */
        public abstract boolean hasPrevious();
        /**
         * This method moves iterator an element forward
         * @return the value that the moved iterator shows
         */
        public abstract T next();
        /**
         * This method moves iterator an element backward
         * @return the value that the moved iterator shows
         */
        public abstract T previous();
        /**
         * This is an optional method that I implemented.
         * @return the current value that the iterator shows
         */
        public abstract T current();
    }
    /**
     * This method checks if the container is empty or not
     * @return true if empty / false if not
     */
    public boolean empty();
    /**
     * getter for memberCount (field loacted at GTUSet)
     * @return member count of the set 
     */
    public int size();
    /**
     * getter for Capacity (field loacted at GTUSet)
     * @return capacity of the set 
     */
    public int max_size();
    /**
     * This is one of the most important methods of this class.It inserts the 
     * given element to the set and increases the memberCount(if successful)  
     * @param val is the value we want to insert to the set 
     * @throws InvalidParameterException when the value we want to insert
     * is already in the set
     */
    public void insert(T val);
    /**
     * This method operates with two sets: this and other
     * @param other is another GTUSet object
     * @return a new set that holds all the elements that both of the sets have 
     * in common
     */
    public GTUSetInt<T> intersection(GTUSet<T> other);
    /**
     * This method erases the given element and decreses the memberCount
     * (if successful)
     * @param val is the value that we want to erase 
     */
    public void erase(T val);
    /**
     * clears the whole set and sets memberCount to 0
     */
    public void clear();
    /**
     * This method checks the set and look up for the given value
     * @param val is the value we search in the set
     * @return 1 if it is found in the set / 0 if not
     */
    public GTUIterator find(T val);
    /**
     * This method searcher for an element and move the cursor to it's location
     * @return the value that the moved iterator shows
     */
    public int count(T val);
    /**
     * This method moves the iterator to the beginning of the set
     * @return the value that the moved iterator shows
     */
    public GTUIterator begin();
    /**
     * This method moves the iterator to the end of the set
     * @return the value that the moved iterator shows
     */
    public GTUIterator end();
}
