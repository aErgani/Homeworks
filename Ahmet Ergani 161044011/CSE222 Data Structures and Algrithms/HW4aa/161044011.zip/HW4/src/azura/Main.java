package azura;

/**
 * Creates 2 GTUGeneral tree objects and tests them
 */
public class Main
{
    public static void main(String args[])
    {
        System.out.println("MEHRUNES DAGON");
        System.out.println("***********Maternal Tree***********");
        GTUGeneralTree<String> maternalTree = new GTUGeneralTree<String>("Emine");
        maternalTree.add("Emine","Halime");
        maternalTree.add("Emine","Mustafa");
        maternalTree.add("Emine","Gulsen");
        maternalTree.add("Emine","Ruhi");
        maternalTree.add("Emine","Ummuhan");
        maternalTree.add("Emine","Seref");
        maternalTree.add("Emine","Eyup");
        maternalTree.add("Emine","Ayse");
        maternalTree.add("Ayse","Nursena");
        maternalTree.add("Ayse","Beyza");
        maternalTree.add("Halime","Cemal");
        maternalTree.add("Halime","Emine");
        maternalTree.add("Halime","Emel");
        maternalTree.add("Halime","Havva");
        maternalTree.add("Emel","Ahmet");
        maternalTree.add("Emel","Eren");
        maternalTree.add("Gulsen","Ahmet");
        maternalTree.add("Gulsen","Musab");
        maternalTree.add("Gulsen","Mehmet Akif");
        maternalTree.add("Ummuhan","Selin");
        maternalTree.add("Ummuhan","Oguzhan");
        System.out.println(maternalTree.toString());
        System.out.println("***********Paternal Tree***********");
        GTUGeneralTree<String> paternalTree = new GTUGeneralTree<String>("Melahat");
        paternalTree.add("Melahat","Meral");
        paternalTree.add("Melahat","Cemil");
        paternalTree.add("Meral","Levent");
        paternalTree.add("Meral","Jale");
        paternalTree.add("Levent","Ahmet");
        paternalTree.add("Levent","Musab");
        paternalTree.add("Levent","Mehmet Akif");
        paternalTree.add("Jale","Merve");
        paternalTree.add("Jale","Murat");
        paternalTree.add("Ahmet","Kayra");
        paternalTree.add("Ahmet","Arya");
        paternalTree.add("Ahmet","Alephca");
        paternalTree.add("Musab","Enver");
        System.out.println(paternalTree.toString());
        BinaryTree.Node<String> father = paternalTree.levelOrderSearch(paternalTree.getRoot(),"Levent");;
        System.out.println("***********My Father***********");
        System.out.println(father.toString());
    }
}
