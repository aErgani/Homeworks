package azura;

/**
 * Represents a general tree as a binary tree, Left node means "child" and right nod means "sibling"
 * @param <E> Generic data type
 */
public class GTUGeneralTree<E> extends BinaryTree<E>
{
    /**
     * Root of the tree
     */
    private Node<E> ancestor;
    /**
     * holds the search results
     */
    public Node<E> temp = null;

    /**
     * Searches the tree in post-order. Creates a node with the childItem if it finds the parent and adds it to the tree
     * @param parentItem is the value that the father of childItem should hold
     * @param childItem is the value we want to insert
     * @return true if successful, false if not
     */
    public boolean add(E parentItem, E childItem)
    {
        temp = postOrderSearch(ancestor,parentItem);
        if(temp == null)
            return false;
        else
        {
            Node<E> childNode = new Node<E>(childItem);
            if(temp.left != null)
            {
                temp = temp.left;
                while(true)
                {
                    if(temp.right == null)
                    {
                        //System.out.println("Added " + childItem + " as sibling of " + temp.toString());
                        temp.right = childNode;
                        temp = null;
                        return true;
                    }
                    else
                        temp = temp.right;
                }
            }
            else
            {
                //System.out.println("Added " + childItem + " as a child of " + temp);
                temp.left = childNode;
                temp = null;
                return true;
            }
        }
    }

    /**
     * assigns null to temp and recursively searches the tree in level-order
     * @param node current node (root at the beginning)
     * @param item data we are searching
     * @return the Node with the wanted data, null if it can't find it
     */
    Node<E> levelOrderSearch(Node<E> node,E item)
    {
        temp = null;
        levelOrderSearchRecursive(node,item);
        return temp;
    }

    /**
     * Recursive part of the levelOrderSearch method
     * @param node current node (root at the beginning)
     * @param item data we are searching
     */
    void levelOrderSearchRecursive(Node<E> node,E item)
    {
        if(node != null)
        {
            if(node.data == item)
                temp = node;
            else
            {
                levelOrderSearchRecursive(node.right,item);
                levelOrderSearchRecursive(node.left,item);
            }
        }
    }
    /**
     * assigns null to temp and recursively searches the tree in post-order
     * @param node current node (root at the beginning)
     * @param item data we are searching
     * @return the Node with the wanted data, null if it can't find it
     */
    Node<E> postOrderSearch(Node<E> node,E item)
    {
        temp = null;
        postOrderSearchRecursive(node,item);
        return temp;
    }
    /**
     * Recursive part of the postOrderSearch method
     * @param node current node (root at the beginning)
     * @param item data we are searching
     */
    void postOrderSearchRecursive(Node<E> node,E item)
    {
        if(node != null)
        {
            postOrderSearchRecursive(node.left,item);
            postOrderSearchRecursive(node.right,item);
            if(node.data == item)
                temp = node;
        }
    }
    @Override
    protected void preOrderTraverse(Node<E> node, int depth,
                          StringBuilder sb)
    {
        if(node != null)
        {
            for (int i = 1; i < depth; i++)
            {
                sb.append("  ");
            }
            sb.append(node.toString() + " ");
            sb.append("\n");
            preOrderTraverse(node.left, depth + 1, sb);
            preOrderTraverse(node.right, depth, sb);

        }
    }

    /**
     * Getter
     * @return root of the General Tree
     */
    public Node<E> getRoot()
    {
        return ancestor;
    }

    /**
     * creates the root of the General Tree with the given data
     * @param data root of the General Tree
     */
    public GTUGeneralTree(E data)
    {
        ancestor = new Node<E>(data);
    }
    @Override
    public String toString()
    {
        StringBuilder sb = new StringBuilder();
        preOrderTraverse(ancestor, 1, sb);
        return sb.toString();
    }
}
