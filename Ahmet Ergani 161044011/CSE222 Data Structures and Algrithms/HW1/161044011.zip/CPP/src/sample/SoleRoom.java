package sample;

/**
 * Room type that has a person limit of 1
 */
public class SoleRoom extends Room
{
    public SoleRoom(int RNo) {personLimit = 1; roomNo = RNo; isEmpty = 0;}
}
