package sample;
import java.util.Scanner;

/**
 * Receptionist is an individual that works in a hotel. Accomplishes the check-in procedure of a booked room
 * Receptionist can also accomplish check-out procedure of an occupied room
 */
public class Receptionist implements Subject
{
    /**
     * The default type of Receptionist subjects is 1
     */
    private int type;
    /**
     * Holds the name of the Receptionist
     */
    private String name;
    /**
     * Holds the surname of the Receptionist
     */
    private String surname;
    /**
     * Holds the username of the Receptionist
     */
    private String username;
    /**
     * Holds the given input when the username is asked
     */
    private String inputUsername;
    /**
     * Holds the password of the Receptionist
     */
    private String password;
    /**
     * Holds the given input when the password is asked
     */
    private String inputPassword;

    /**
     * Asks the Receptionist's staff number,then his/her username and password. After that log-in process,lets the
     * Receptionist check in or check out an individual
     * @param roomArray holds all the rooms in the Hotel
     * @param Guests holds all the Guests that are in the hotel or boooked a room
     * @return 0 after the end of the process
     */
    @Override
    public int reg(Room[] roomArray, Guest [] Guests)
    {
        System.out.println("Enter Username");
        inputUsername = A.scanner.nextLine();
        System.out.println("Enter Password");
        inputPassword = A.scanner.nextLine();
        while(!(regCheck()))
        {
            System.err.println("INVALID USERNAME OR PASSWORD!");
            System.err.println("Enter Username");
            inputUsername = A.scanner.nextLine();
            System.err.println("Enter Password");
            inputPassword = A.scanner.nextLine();
        }
        System.out.println("Welcome " + name + " " + surname);
        this.book(roomArray,Guests);
        return 0;
    }

    /**
     * Checks the username and password
     * @return true if input and data match, false if not
     */
    private boolean regCheck()
    {
        return (inputUsername.equals(username) && inputPassword.equals(password));
    }

    /**
     * Lets the Receptionist search the Guests by name. If that Guest has booked a room, Receptionist can check the
     * individual in. If that Guest is currently occupying any room, Receptionist can check the individual out
     * @param roomArray holds all the rooms in the Hotel
     * @param Guests holds all the Guests that are in the hotel or boooked a room
     * @return 1 after check in or check out, 0 if no action has happened
     */
    @Override
    public int book(Room[] roomArray,Guest [] Guests)
    {
        int flag = 58;
        String GuestName,GuestSurname;
        System.out.println("Type Guest's name");
        GuestName = A.scanner.nextLine();
        System.out.println("Type Guest's surname");
        GuestSurname = A.scanner.nextLine();
        for(int i = 0; i < 20; i++)
            if(Guests[i] != null && Guests[i].name.equals(GuestName) && Guests[i].surname.equals(GuestSurname))
                flag = i;
        if(flag != 58)
        {
            if (roomArray[flag].isEmpty == 2)
            {
                System.out.println("Guest is currently occupying a room, Check the individual out? Y/N?");
                String choice = A.scanner.nextLine();
                while(!choice.equals("Y") && !choice.equals("N"))
                {
                    System.out.println("INVALID INPUT TRY AGAIN");
                    choice = A.scanner.nextLine();
                }
                if(choice.equals("Y"))
                {
                    Guests[flag] = null;
                    roomArray[flag].isEmpty = 0;
                    return 1;
                }
                else
                    return 0;
            }
            else if(roomArray[flag].isEmpty == 1)
            {
                System.out.println("Guest has booked a room, Check the individual in? Y/N?");
                String choice = A.scanner.nextLine();
                while(!choice.equals("Y") && !choice.equals("N"))
                {
                    System.out.println("INVALID INPUT TRY AGAIN");
                    choice = A.scanner.nextLine();
                }
                if(choice.equals("Y"))
                {
                    roomArray[flag].isEmpty = 2;
                    return 1;
                }
                else
                    return 0;
            }
        }
        else
        {
            System.out.println("Unknown Guest");
            return 0;
        }
        return 2;
    }
    public Receptionist(String n, String s,String u,String p) {name = n; surname = s; type = 1; username = u; password = p;}

    /* ********************************************** */

    /**
     * This is an overload of book method. I needed this overload because I use scanner in original method
     * @param roomArray holds all the room in the Hotel
     * @param Guests holds all the Guests that are in the hotel or boooked a room
     * @return 1 after a successful reservation cancel, 0 if the guest hasn't booked any room
     */
    public int bookTest(Room[] roomArray,Guest [] Guests,String choice, String GuestName,String GuestSurname)
    {
        int flag = 58;
        for(int i = 0; i < 20; i++)
            if(Guests[i] != null && Guests[i].name.equals(GuestName) && Guests[i].surname.equals(GuestSurname))
                flag = i;
        if(flag != 58)
        {
            if (roomArray[flag].isEmpty == 2)
            {
                System.out.println("Guest is currently occupying a room, Check the individual out? Y/N?");
                while(!choice.equals("Y") && !choice.equals("N"))
                {
                    System.out.println("INVALID INPUT TRY AGAIN");
                    choice = A.scanner.nextLine();
                }
                if(choice.equals("Y"))
                {
                    Guests[flag] = null;
                    roomArray[flag].isEmpty = 0;
                    return 1;
                }
                else
                    return 0;
            }
            else if(roomArray[flag].isEmpty == 1)
            {
                System.out.println("Guest has booked a room, Check the individual in? Y/N?");
                while(!choice.equals("Y") && !choice.equals("N"))
                {
                    System.out.println("INVALID INPUT TRY AGAIN");
                    choice = A.scanner.nextLine();
                }
                if(choice.equals("Y"))
                {
                    roomArray[flag].isEmpty = 2;
                    return 1;
                }
                else
                    return 0;
            }
        }
        else
        {
            System.out.println("Unknown Guest");
            return 0;
        }
        return 2;
    }
}
