package sample;

import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

/**
 * Tests the Receptioist Class' Methods
 */
class ReceptionistTest
{

    @Test
    void book()
    {
        Receptionist tempReceptionist = new Receptionist("Ahmet","Ergani","ahmtergn5","123456");
        Guest tempGuest = new Guest("Lev","Tolstoy");
        Guest [] Guests = new Guest[20];
        Room[] roomArray = new Room[20];
        for(int i = 0; i < 10; i++)
            roomArray[i] = new SoleRoom(i+1);
        for(int i = 10; i < 15; i++)
            roomArray[i] = new CoupleRoom(i+1);
        for(int i = 15; i < 20; i++)
            roomArray[i] = new FamilyRoom(i+1);
        Guests[18] = tempGuest;
        roomArray[18].isEmpty = 2;
        int returnVal = tempReceptionist.bookTest(roomArray,Guests,"Y","Lev","Tolstoy");
        assertEquals(returnVal,1);
    }
}