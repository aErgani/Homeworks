package sample;
import java.io.FileWriter;
public interface Subject
{

    /**
     * Column that stores Room numbers
     */
    int ROOM_NO = 0;
    /**
     * Column that holds the room status
     */
    int ROOM_STATUS = 1;
    /**
     * Column that holds the names of the guests
     */
    int GUEST_NAME = 2;
    /**
     * Column that holds the surnames of the guests
     */
    int GUEST_SURNAME = 3;
    /**
     * next CSV cell
     */
    String COMMA_DELIMITER = ",";
    /**
     * New line
     */
    String NEW_LINE_SEPARATOR = "\n";

    /**
     * Welcomes the subject. If subject is a guest asks for name and surname, If subject is a receptionist asks for
     * username and password
     * @param roomArray holds all the rooms in the Hotel
     * @param Guests holds all the Guests that are in the hotel or boooked a room
     * @return 1 if the process is successful, 0 if not
     */
    public abstract int reg(Room[] roomArray,Guest [] Guests);

    /**
     * Lets a guest book a room. Lets a receptionist check-in or check-out an individual
     * @param roomArray holds all the rooms in the Hotel
     * @param Guests holds all the Guests that are in the hotel or boooked a room
     * @return 1 if the process is successful, 0 if not
     */
    public abstract int book(Room[] roomArray,Guest [] Guests);
}
