package sample;

/**
 * This Class is the essential part of the Hotel
 */
public abstract class Room
{
    /**
     * Holds the person limit of a room
     */
    protected int personLimit;
    /**
     * Holds the identifier of a room
     */
    protected int roomNo;
    /**
     * holds 0 if the room is empty, 1 if it is booked, 2 if it is occupied
     */
    public int isEmpty;
}
