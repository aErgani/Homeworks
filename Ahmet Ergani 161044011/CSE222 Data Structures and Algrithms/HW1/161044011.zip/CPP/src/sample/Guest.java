package sample;
import java.util.Scanner;


/**
 * Guest is an individual person who can book a room before his/her arrival to Hotel
 * Guest can also cancel his/her reservation too, using another method of this class
 */
public class Guest implements Subject
{
    /**
     * The default type of Guest subjects is 0
     */
    private int type;
    /**
     * Holds the name of the Guest
     */
    public String name;
    /**
     * Holds the surname of the guest
     */
    public String surname;
    /**
     * Holds the current choice input. Changes multiple times during procedures
     */
    private String choice;
    /**
     * Lists available room types for the guest and asks which type he/she would like to book
     * @param roomArray holds all the rooms in the Hotel
     * @param Guests holds all the Guests that are in the hotel or boooked a room
     * @return 0 if Hotel is full, 1 after a successful book
     */
    @Override
    public int book(Room[] roomArray,Guest [] Guests)
    {
        int i = 0;
        boolean s = true;   /*for SoleRoom check*/
        boolean c = true;   /*for CoupleRoom check*/
        boolean f = true;   /*for FamilyRoom check*/
        for (i = 0; i < 10; i++)        /*Checks if there is any empty SoleRoom exists*/
        {
            if (roomArray[i].isEmpty == 0)
            {
                System.out.println("You can choose a SoleRoom");
                break;
            }
            if (i == 9)
            {
                System.out.println("All SoleRooms are currently occupied");
                s = false;
            }
        }
        for (i = 10; i < 15; i++)       /*Checks if there is any empty CoupleRoom exists*/
        {
            if (roomArray[i].isEmpty == 0)
            {
                System.out.println("You can choose a CoupleRoom");
                break;
            }
            if (i == 14)
            {
                System.out.println("All CoupleRooms are currently occupied");
                c = false;
            }
        }
        for (i = 15; i < 20; i++)       /*Checks if there is any empty FamilyRoom exists*/
        {
            if (roomArray[i].isEmpty == 0)
            {
                System.out.println("You can choose a FamilyRoom");
                break;
            }
            if (i == 19)
            {
                System.out.println("All FamilyRooms are currently occupied");
                f = false;
            }
        }
        if (!s && !c && !f)          /*NO ROOM AVAILABLE*/
        {
            System.out.println("Currently, there are no available rooms in Hotel California. Sorry for the inconvenience");
            return 0;
        } else        /*Asking the type of the room*/
        {
            if (s)
                System.out.println("Type 's' to book a SoleRoom");
            if (c)
                System.out.println("Type 'c' to book a CoupleRoom");
            if (f)
                System.out.println("Type 'f' to book a FamilyRoom");
            choice = A.scanner.nextLine();
            if (!choice.equals("s") && !choice.equals("c") && !choice.equals("f")) /*invalid input*/
                while (true)
                {
                    System.out.println("You have entered an invalid input. try again");
                    choice = A.scanner.nextLine();
                    if (choice.equals("s") || choice.equals("c") || choice.equals("f"))
                        break;
                }
            if (choice.equals("s") && s)         /*Sole room chosen*/
            {
                for (i = 0; i < 10; i++)
                    if (roomArray[i].isEmpty == 0)
                    {
                        roomArray[i].isEmpty = 1;
                        Guests[i] = this;
                        System.out.println("Room successfully booked. Room no : " + (i + 1) + " . You will be checked in as soon as you come to the Hotel California. Have a nice day");
                        return 1;
                    }
            }
            else if (choice.equals("c") && c)    /*Couple room chosen*/
            {
                        for (i = 10; i < 15; i++)
                            if (roomArray[i].isEmpty == 0)
                            {
                                roomArray[i].isEmpty = 1;
                                Guests[i] = this;
                                System.out.println("Room successfully booked. Room no : " + (i + 1) + " . You will be checked in as soon as you come to the Hotel California. Have a nice day");
                                return 1;
                            }
            }
            else if (choice.equals("f") && f)    /*Family room chosen*/
            {
                for (i = 15; i < 20; i++)
                    if (roomArray[i].isEmpty  == 0)
                    {
                        roomArray[i].isEmpty = 1;
                        Guests[i] = this;
                        System.out.println("Room successfully booked. Room no : " + (i + 1) + " . You will be checked in as soon as you come to the Hotel California. Have a nice day");
                        return 1;
                    }
            }
        }
        return 0;
    }
    /**
     *Lets guest cancel his/her reservation (if there is one)
     * @param roomArray holds all the room in the Hotel
     * @param Guests holds all the Guests that are in the hotel or boooked a room
     * @return 1 after a successful reservation cancel, 0 if the guest hasn't booked any room
     */
    public int cancel(Room[] roomArray,Guest [] Guests)
    {
        int flag = 58;
        for(int i = 0; i < 20; i++)
            if(Guests[i] != null && Guests[i].name.equals(name) && Guests[i].surname.equals(surname))
                flag = i;
        if(flag != 58)
        {
            roomArray[flag].isEmpty = 0;
            Guests[flag] = null;
            flag++;
            System.out.println("Your reservation of Room " + flag + " has been canceled. Have a nice day");
        }
        else
        {
            System.out.println("There are no rooms booked for you right now");
            return 0;
        }
        return 1;
    }

    /**
     * Takes the name and surname of the guest, Records that data to csv and lets the guest book or "cancel reservation" according to his/her choice
     * @param roomArray holds all the room in the Hotel
     * @param Guests holds all the Guests that are in the hotel or boooked a room
     * @return 0 after process
     */
    @Override
    public int reg(Room[] roomArray,Guest [] Guests)
    {
        String choice;
        System.out.println("Welcome to the Hotel California");
        System.out.println("Enter Name");
        name = A.scanner.nextLine();
        System.out.println("Enter Surname");
        surname = A.scanner.nextLine();
        System.out.println("Welcome " + name + " " + surname);
        System.out.println("Type 'b' if you like to book a room. Type 'c' if you want to cancel your reservation");
        choice = A.scanner.nextLine();
        if(choice.equals("b"))
        {
            System.out.println("There are 3 types of rooms in Hotel California.");
            System.out.println("SoleRooms have a capacity of 1, CoupleRooms have a capacity of 2, FamilyRooms have a capacity of 4");
            this.book(roomArray, Guests);
        }
        else
            this.cancel(roomArray,Guests);
        return 0;
    }
    public Guest() {type = 0;}
    public Guest(String firstName,String lastName) {type = 0;name = firstName; surname = lastName;}

    /**
     *
     * @return name and surname of the Guest divided with a space
     */
    public String toString()
    {
        return name + " " + surname;
    }
    /* *************************************** */

    /**
     * This is an overload of book method. I needed this overload because I use scanner in original method
     * @param roomArray holds all the room in the Hotel
     * @param Guests holds all the Guests that are in the hotel or boooked a room
     * @param choiceTest is the desired choice for the test. Normally I assign the input that I got from scanner
     * @return 1 if successful, 0 if Hotel is full
     */
    public int bookTest(Room[] roomArray,Guest [] Guests,String choiceTest)
    {
        int i = 0;
        boolean s = true;   /*for SoleRoom check*/
        boolean c = true;   /*for CoupleRoom check*/
        boolean f = true;   /*for FamilyRoom check*/
        for (i = 0; i < 10; i++)        /*Checks if there is any empty SoleRoom exists*/
        {
            if (roomArray[i].isEmpty == 0)
            {
                System.out.println("You can choose a SoleRoom");
                break;
            }
            if (i == 9)
            {
                System.out.println("All SoleRooms are currently occupied");
                s = false;
            }
        }
        for (i = 10; i < 15; i++)       /*Checks if there is any empty CoupleRoom exists*/
        {
            if (roomArray[i].isEmpty == 0)
            {
                System.out.println("You can choose a CoupleRoom");
                break;
            }
            if (i == 14)
            {
                System.out.println("All CoupleRooms are currently occupied");
                c = false;
            }
        }
        for (i = 15; i < 20; i++)       /*Checks if there is any empty FamilyRoom exists*/
        {
            if (roomArray[i].isEmpty == 0)
            {
                System.out.println("You can choose a FamilyRoom");
                break;
            }
            if (i == 19)
            {
                System.out.println("All FamilyRooms are currently occupied");
                f = false;
            }
        }
        if (!s && !c && !f)          /*NO ROOM AVAILABLE*/
        {
            System.out.println("Currently, there are no available rooms in Hotel California. Sorry for the inconvenience");
            return 0;
        } else        /*Asking the type of the room*/
        {
            if (s)
                System.out.println("Type 's' to book a SoleRoom");
            if (c)
                System.out.println("Type 'c' to book a CoupleRoom");
            if (f)
                System.out.println("Type 'f' to book a FamilyRoom");
            if (!choiceTest.equals("s") && !choiceTest.equals("c") && !choiceTest.equals("f")) /*invalid input*/
                while (true)
                {
                    System.out.println("You have entered an invalid input. try again");
                    choiceTest = A.scanner.nextLine();
                    if (choiceTest.equals("s") || choiceTest.equals("c") || choiceTest.equals("f"))
                        break;
                }
            if (choiceTest.equals("s") && s)         /*Sole room chosen*/
            {
                for (i = 0; i < 10; i++)
                    if (roomArray[i].isEmpty == 0)
                    {
                        roomArray[i].isEmpty = 1;
                        Guests[i] = this;
                        System.out.println("Room successfully booked. Room no : " + (i + 1) + " . You will be checked in as soon as you come to the Hotel California. Have a nice day");
                        return 1;
                    }
            }
            else if (choiceTest.equals("c") && c)    /*Couple room chosen*/
            {
                System.out.println("ENTER HERE");
                for (i = 10; i < 15; i++)
                    if (roomArray[i].isEmpty == 0)
                    {
                        roomArray[i].isEmpty = 1;
                        Guests[i] = this;
                        System.out.println("Room successfully booked. Room no : " + (i + 1) + " . You will be checked in as soon as you come to the Hotel California. Have a nice day");
                        return 1;
                    }
            }
            else if (choiceTest.equals("f") && f)    /*Family room chosen*/
            {
                for (i = 15; i < 20; i++)
                    if (roomArray[i].isEmpty  == 0)
                    {
                        roomArray[i].isEmpty = 1;
                        Guests[i] = this;
                        System.out.println("Room successfully booked. Room no : " + (i + 1) + " . You will be checked in as soon as you come to the Hotel California. Have a nice day");
                        return 1;
                    }
            }
        }
        return 0;
    }
}
