package sample;
import java.io.FileReader;
import java.util.Scanner;
import java.io.FileWriter;
import java.io.IOException;
import java.io.BufferedReader;

/**
 * Holds the main method. Reads all the Data from a csv file, fills the necessary arrays. asks the user
 * type to the user and handles the process accordingly. After a termination of a process (book, check-out etc)
 *  it updates the csv file according to the modified arrays
 */
public class A
{
    /**
     * Scanner for getting input from Subjects
     */
    public static Scanner scanner = new Scanner(System.in);
    private static final int ROOM_NO = 0;
    private static final int ROOM_STATUS = 1;
    private static final int GUEST_NAME = 2;
    private static final int GUEST_SURNAME = 3;
    private static final String COMMA_DELIMITER = ",";
    private static final String NEW_LINE_SEPARATOR = "\n";
    public static void main(String[]args)
    {
        Subject tempGuest;
        int j;
        boolean[] GuestIndex = new boolean[20];
        for(j = 0; j < 20; j++)
            GuestIndex[j] = true;
        Room[] roomArray = new Room[20];
        for(int i = 0; i < 10; i++)
            roomArray[i] = new SoleRoom(i);
        for(int i = 10;i < 15; i++)
            roomArray[i] = new CoupleRoom(i);
        for(int i = 15;i < 20; i++)
            roomArray[i] = new FamilyRoom(i);
        Subject[] Staff = new Subject[3];
        Guest[] Guests = new Guest[20];
        BufferedReader fileReader = null;
        String roomLine = "";
        try
        {
            fileReader = new BufferedReader(new FileReader("Rooms.csv"));
            for(int i = 0; i < 20; i++)
            {
                roomLine = fileReader.readLine();
                String[] data = roomLine.split(COMMA_DELIMITER);
                if (data.length > 0)
                    if(!data[1].equals("EMPTY"))
                    {
                        if(data[1].equals("FULL"))
                            roomArray[i].isEmpty = 2;
                        else if(data[1].equals("BOOKED"))
                            roomArray[i].isEmpty = 1;
                        Guests[i] = new Guest(data[GUEST_NAME],data[GUEST_SURNAME]);
                    }
            }
        }
        catch (Exception e)
        {
            System.out.println("Error in CsvFileReader !");
            e.printStackTrace();
        }
        Staff[0] = new Receptionist("Ahmet","Ergani","ahmtergn5","123456");
        Staff[1] = new Receptionist("Elif","Kucukpinar","elifkpnr","123456");
        Staff[2] = new Receptionist("Alihan","Ozturk","hsnyca","123456");
        System.out.println("Welcome to the Hotel California");
        System.out.println("Type 'ADMIN' for Staff Entrance, type something else for Guest Entrance");
        String strInput = A.scanner.nextLine();
        if(strInput.equals("ADMIN"))
        {
            System.out.println("Enter your staff number");
            strInput = A.scanner.nextLine();
            if(!strInput.equals("0") && !strInput.equals("1") && !strInput.equals("2"))
                while(true)
                {
                    System.err.println("INVALID INPUT!");
                    System.err.println("Enter Username");
                    strInput = A.scanner.nextLine();
                    if(strInput.equals("0") && strInput.equals("1") && strInput.equals("2"))
                        break;
                }
            if(strInput.equals("0"))
                Staff[0].reg(roomArray,Guests);
            if(strInput.equals("1"))
                Staff[1].reg(roomArray,Guests);
            if(strInput.equals("2"))
                Staff[2].reg(roomArray,Guests);
        }
        else
        {
            for(j = 0;j < 20; j++)
                if(GuestIndex[j])
                    break;
            GuestIndex[j] = false;
            tempGuest = new Guest();
            tempGuest.reg(roomArray,Guests);
        }
        int i;                          //TERMINATION
        FileWriter fileWriter = null;
        try
        {
            fileWriter = new FileWriter("Rooms.csv",false);
        }
        catch (Exception e)
        {
            System.out.println("Error in CsvFileWriter!");
            e.printStackTrace();
        }
        for(i = 0; i< 20; i++)
            try
            {
                i++;
                fileWriter.append("ROOM ").append(String.valueOf(i));
                i--;
                fileWriter.append(COMMA_DELIMITER);
                if(Guests[i] == null)
                    fileWriter.append("EMPTY");
                else
                {
                    //System.out.println(i + " Musteri var odada " + Guests[i].toString());
                    if(roomArray[i].isEmpty == 1)
                        fileWriter.append("BOOKED");
                    else if(roomArray[i].isEmpty == 2)
                        fileWriter.append("FULL");
                    fileWriter.append(COMMA_DELIMITER);
                    fileWriter.append(Guests[i].name);
                    fileWriter.append(COMMA_DELIMITER);
                    fileWriter.append(Guests[i].surname);
                }
                fileWriter.append(NEW_LINE_SEPARATOR);
            } catch (Exception e)
            {
                System.out.println("Error in CsvFileWriter!");
                e.printStackTrace();
            }
        try
        {
            fileWriter.flush();
            fileWriter.close();
        } catch (IOException e)
        {
            System.out.println("Error while flushing/closing fileWriter!");
            e.printStackTrace();
        }
    }
}
