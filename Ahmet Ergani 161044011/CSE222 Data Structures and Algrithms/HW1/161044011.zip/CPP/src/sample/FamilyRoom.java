package sample;

/**
 * Room type that has a person limit of 4
 */
public class FamilyRoom extends Room
{
    public FamilyRoom(int RNo) {personLimit = 1; roomNo = RNo; isEmpty = 0;}
}
