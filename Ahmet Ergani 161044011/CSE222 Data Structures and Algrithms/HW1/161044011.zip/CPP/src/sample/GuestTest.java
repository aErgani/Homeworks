package sample;

import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

/**
 * Tests the Guest Class' Methods
 */
class GuestTest
{

    @Test
    void book()
    {
        String choice = "c";
        Guest tempGuest = new Guest("ahmet","ergani");
        Guest [] Guests = new Guest[20];
        Room[] roomArray = new Room[20];
        for(int i = 0; i < 10; i++)
            roomArray[i] = new SoleRoom(i+1);
        for(int i = 10; i < 15; i++)
            roomArray[i] = new CoupleRoom(i+1);
        for(int i = 15; i < 20; i++)
            roomArray[i] = new FamilyRoom(i+1);
        int returnVal = tempGuest.bookTest(roomArray,Guests,choice);
        assertEquals(returnVal,1);
    }

    @Test
    void cancel()
    {
        Guest tempGuest = new Guest("ahmet","ergani");
        Guest [] Guests = new Guest[20];
        Room[] roomArray = new Room[20];
        for(int i = 0; i < 10; i++)
            roomArray[i] = new SoleRoom(i+1);
        for(int i = 10; i < 15; i++)
            roomArray[i] = new CoupleRoom(i+1);
        for(int i = 15; i < 20; i++)
            roomArray[i] = new FamilyRoom(i+1);
        Guests[18] = tempGuest;
        roomArray[18].isEmpty = 2;
        int returnVal = tempGuest.cancel(roomArray,Guests);
        assertEquals(returnVal,1);
    }
}