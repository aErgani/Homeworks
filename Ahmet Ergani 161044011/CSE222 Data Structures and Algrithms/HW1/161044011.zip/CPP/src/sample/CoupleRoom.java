package sample;
/**
 * Room type that has a person limit of 2
 */
public class CoupleRoom extends Room
{
    public CoupleRoom(int RNo) {personLimit = 1; roomNo = RNo; isEmpty = 0;}
}
