package sample;
import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;

/**
 * Lets the Main class get input from a .txt file
 */
public class MainWrapper
{
    public static void main(String[] args) throws IOException
    {
        FileInputStream is = new FileInputStream(new File("1.txt"));
        System.setIn(is);
        A.main(args);
    }
}